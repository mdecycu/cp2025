使用 mingw 編譯 raylib

git clone https://github.com/raysan5/raylib.git
cd raylib
mkdir build && cd build
cmake .. -G "MinGW Makefiles" 
mingw32-make